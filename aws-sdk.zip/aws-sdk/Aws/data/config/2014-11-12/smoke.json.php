<?php
// This file was auto-generated from sdk-root/src/data/config/2014-11-12/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeConfigurationRecorders', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'GetResourceConfigHistory', 'input' => [ 'resourceType' => 'fake-type', 'resourceId' => 'fake-id', ], 'errorExpectedFromService' => true, ], ],];
