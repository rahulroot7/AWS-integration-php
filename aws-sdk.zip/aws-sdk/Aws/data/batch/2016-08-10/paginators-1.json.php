<?php
// This file was auto-generated from sdk-root/src/data/batch/2016-08-10/paginators-1.json
return [ 'pagination' => [],];
